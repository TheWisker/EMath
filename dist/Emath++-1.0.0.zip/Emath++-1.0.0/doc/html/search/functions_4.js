var searchData=
[
  ['test_5fmonomial_0',['test_monomial',['../test_2emath_8cpp.html#ab880f6083075d1f2c3c6ca54d36fba6f',1,'emath.cpp']]],
  ['test_5fpolynomial_1',['test_polynomial',['../test_2emath_8cpp.html#ada79f825efa86697f40154987f0f6129',1,'emath.cpp']]]
];
