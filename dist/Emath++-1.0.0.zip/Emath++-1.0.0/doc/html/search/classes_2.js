var searchData=
[
  ['polynomial_0',['Polynomial',['../classemth_1_1Polynomial.html',1,'emth']]]
];
