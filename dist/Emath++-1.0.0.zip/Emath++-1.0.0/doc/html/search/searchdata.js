var indexSectionsWithContent =
{
  0: "aegmopt~",
  1: "amp",
  2: "e",
  3: "e",
  4: "gmopt~",
  5: "o",
  6: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "related",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Friends",
  6: "Pages"
};

