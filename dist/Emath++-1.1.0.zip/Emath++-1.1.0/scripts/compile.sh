cd ./bin
meson configure --optimization=1 --buildtype=plain
meson compile
cd ..