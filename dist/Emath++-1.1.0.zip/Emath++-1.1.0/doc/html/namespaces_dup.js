var namespaces_dup =
[
    [ "emth", "namespaceemth.html", "namespaceemth" ],
    [ "emthp", "namespaceemthp.html", "namespaceemthp" ]
];