var annotated_dup =
[
    [ "emth", "namespaceemth.html", [
      [ "Arithmetic", "classemth_1_1Arithmetic.html", null ],
      [ "Monomial", "classemth_1_1Monomial.html", "classemth_1_1Monomial" ],
      [ "Polynomial", "classemth_1_1Polynomial.html", "classemth_1_1Polynomial" ]
    ] ],
    [ "emthp", "namespaceemthp.html", [
      [ "Lexer", "classemthp_1_1Lexer.html", "classemthp_1_1Lexer" ],
      [ "Parser", "classemthp_1_1Parser.html", "classemthp_1_1Parser" ],
      [ "Token", "structemthp_1_1Token.html", "structemthp_1_1Token" ]
    ] ],
    [ "EParserTest", "classEParserTest.html", "classEParserTest" ]
];