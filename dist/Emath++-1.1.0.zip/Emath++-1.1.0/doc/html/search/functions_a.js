var searchData=
[
  ['_7emonomial_0',['~Monomial',['../classemth_1_1Monomial.html#aecedb04edd52a33ba0ee110eedbd74db',1,'emth::Monomial']]],
  ['_7epolynomial_1',['~Polynomial',['../classemth_1_1Polynomial.html#a056e1df4102b0d0add0e8e2805401b82',1,'emth::Polynomial']]]
];
