var indexSectionsWithContent =
{
  0: "abcefgilmnoprstvwy~",
  1: "aeilmopstvw",
  2: "e",
  3: "efi",
  4: "befgilmnoprstvw~",
  5: "cloprtvy",
  6: "t",
  7: "t",
  8: "o",
  9: "et"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Pages"
};

