var searchData=
[
  ['needs_5fupdate_0',['needs_update',['../classefc_1_1Window.html#a2f46320775d22ce67fdbacf50772fd02',1,'efc::Window']]],
  ['next_1',['next',['../classemthp_1_1Lexer.html#a629ea5f393603e05dad17b004caba27d',1,'emthp::Lexer::next()'],['../classefc_1_1Lexer.html#a3eb3b61f1ba41e9d3150052b6280167b',1,'efc::Lexer::next()']]]
];
