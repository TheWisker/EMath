var classefc_1_1Storage =
[
    [ "Storage", "classefc_1_1Storage.html#a9a9cfce79f418f1ad0ee0bb53bb9d048", null ],
    [ "~Storage", "classefc_1_1Storage.html#a5d83512b8daaf9e2cb188f877cb7bb5b", null ],
    [ "exists", "classefc_1_1Storage.html#ac141ea203205c34ebd653682d88b7e2c", null ],
    [ "read", "classefc_1_1Storage.html#a62ca8189455b39656aa25531c3875cbd", null ],
    [ "write", "classefc_1_1Storage.html#af2c8369dcb906c07867a931387659788", null ]
];