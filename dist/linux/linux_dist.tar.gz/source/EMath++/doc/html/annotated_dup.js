var annotated_dup =
[
    [ "efc", "namespaceefc.html", [
      [ "Application", "classefc_1_1Application.html", "classefc_1_1Application" ],
      [ "IWindow", "classefc_1_1IWindow.html", "classefc_1_1IWindow" ],
      [ "Lexer", "classefc_1_1Lexer.html", "classefc_1_1Lexer" ],
      [ "OWindow", "classefc_1_1OWindow.html", "classefc_1_1OWindow" ],
      [ "Parser", "classefc_1_1Parser.html", "classefc_1_1Parser" ],
      [ "Plane", "classefc_1_1Plane.html", "classefc_1_1Plane" ],
      [ "Storage", "classefc_1_1Storage.html", "classefc_1_1Storage" ],
      [ "Terminal", "classefc_1_1Terminal.html", "classefc_1_1Terminal" ],
      [ "Token", "structefc_1_1Token.html", "structefc_1_1Token" ],
      [ "Window", "classefc_1_1Window.html", "classefc_1_1Window" ]
    ] ],
    [ "emth", "namespaceemth.html", [
      [ "Arithmetic", "classemth_1_1Arithmetic.html", null ],
      [ "Monomial", "classemth_1_1Monomial.html", "classemth_1_1Monomial" ],
      [ "Polynomial", "classemth_1_1Polynomial.html", "classemth_1_1Polynomial" ]
    ] ],
    [ "emthp", "namespaceemthp.html", [
      [ "Lexer", "classemthp_1_1Lexer.html", "classemthp_1_1Lexer" ],
      [ "Parser", "classemthp_1_1Parser.html", "classemthp_1_1Parser" ],
      [ "Token", "structemthp_1_1Token.html", "structemthp_1_1Token" ]
    ] ],
    [ "EParserTest", "classEParserTest.html", "classEParserTest" ],
    [ "value", "unionvalue.html", null ]
];