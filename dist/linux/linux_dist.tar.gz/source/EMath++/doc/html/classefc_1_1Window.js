var classefc_1_1Window =
[
    [ "Window", "classefc_1_1Window.html#ae5fb6b6600ebc4b528d664e8c6947ab2", null ],
    [ "~Window", "classefc_1_1Window.html#ac8ec94fb12450e4fc37ea2adc30f81f8", null ],
    [ "get_height", "classefc_1_1Window.html#a0f64ddda75fb64027eaa7b7dd767ec4e", null ],
    [ "get_title", "classefc_1_1Window.html#a933c7e9e67d7423b1facb73a26a9fba3", null ],
    [ "get_title_size", "classefc_1_1Window.html#aad12ba19cc558f386a4f2f9e7b6f1acc", null ],
    [ "get_title_x", "classefc_1_1Window.html#a2e177d9c72e6f7fcf29371df5bc08bea", null ],
    [ "get_title_y", "classefc_1_1Window.html#a910926d607d7ac88e4d5e6640a52836a", null ],
    [ "get_width", "classefc_1_1Window.html#a58e0eb74a3b1b20a268dae29d4525dad", null ],
    [ "get_x", "classefc_1_1Window.html#a1920c8ff02f120a08252797280a3a2aa", null ],
    [ "get_y", "classefc_1_1Window.html#a433fbcc875c6e134a8c273c46525bca2", null ],
    [ "is_active", "classefc_1_1Window.html#a64f20e7199e6a9e85c1db282cd820ad6", null ],
    [ "needs_update", "classefc_1_1Window.html#a2f46320775d22ce67fdbacf50772fd02", null ],
    [ "place", "classefc_1_1Window.html#a2feeecd90c7c634a15c4e84a3921ee14", null ],
    [ "set_active", "classefc_1_1Window.html#a18c9f4d362aa8ae7cd322e038828e4de", null ],
    [ "set_coords", "classefc_1_1Window.html#adb89ea880c531bb3e611378ec1f10f5f", null ],
    [ "set_size", "classefc_1_1Window.html#ad9f8b6f349dfe11addce9781a4e32ffb", null ],
    [ "set_title", "classefc_1_1Window.html#aead8ed85b65db6a0b0c27d34903b8db5", null ],
    [ "c", "classefc_1_1Window.html#add171873b1a7a5c5e1263e8b3a61b6f9", null ],
    [ "o", "classefc_1_1Window.html#ab18720ed62461884b759594ed60fb824", null ],
    [ "t", "classefc_1_1Window.html#a7dc5e87a2ff69618b81041809b052e70", null ],
    [ "y", "classefc_1_1Window.html#a560218b58e4b8e0a87d17d9d51c75ee0", null ]
];