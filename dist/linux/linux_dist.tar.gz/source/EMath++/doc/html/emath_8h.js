var emath_8h =
[
    [ "emth::Arithmetic", "classemth_1_1Arithmetic.html", null ],
    [ "emth::Monomial", "classemth_1_1Monomial.html", "classemth_1_1Monomial" ],
    [ "emth::Polynomial", "classemth_1_1Polynomial.html", "classemth_1_1Polynomial" ]
];