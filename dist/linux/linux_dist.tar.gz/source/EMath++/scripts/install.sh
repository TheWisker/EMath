cd ./bin
meson configure --buildtype=release --optimization=3
sudo meson install
cd ..