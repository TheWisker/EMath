cd ./bin
meson configure --optimization=3 --buildtype=release
meson compile
cd ..