var searchData=
[
  ['read_0',['read',['../classefc_1_1Storage.html#a62ca8189455b39656aa25531c3875cbd',1,'efc::Storage']]],
  ['roboto_5fbold_1',['ROBOTO_BOLD',['../font_8h.html#abee0e1ab69379ae42c9c1ddd2a3ce67e',1,'font.h']]],
  ['roboto_5fbold_5fsize_2',['ROBOTO_BOLD_SIZE',['../font_8h.html#ae0ebae1583ff9713f2ddd26ec457f21d',1,'font.h']]],
  ['run_3',['run',['../classefc_1_1Plane.html#a972b3c48d4213d433dc4b3e99ded3727',1,'efc::Plane::run()'],['../classefc_1_1Application.html#a151fab3a86220c774be08189cf8dcb46',1,'efc::Application::run()']]]
];
