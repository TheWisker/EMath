var namespaces_dup =
[
    [ "efc", "namespaceefc.html", "namespaceefc" ],
    [ "emth", "namespaceemth.html", "namespaceemth" ],
    [ "emthp", "namespaceemthp.html", "namespaceemthp" ]
];