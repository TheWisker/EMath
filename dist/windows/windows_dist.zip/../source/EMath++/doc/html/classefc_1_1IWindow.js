var classefc_1_1IWindow =
[
    [ "IWindow", "classefc_1_1IWindow.html#af8bd92992015e0b7f07a726ed2f329e5", null ],
    [ "~IWindow", "classefc_1_1IWindow.html#a373ef8f5d58d8d99852a90f7096cfdef", null ],
    [ "get_title_x", "classefc_1_1IWindow.html#a91e48b892bd02b7c11020fdfc7e7c05d", null ],
    [ "get_title_y", "classefc_1_1IWindow.html#a84cb0d425e279cd2b15dc2b43cb520d2", null ]
];