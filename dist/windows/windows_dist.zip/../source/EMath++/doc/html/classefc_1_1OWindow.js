var classefc_1_1OWindow =
[
    [ "OWindow", "classefc_1_1OWindow.html#a004301001ab6897854d50d001524c952", null ],
    [ "~OWindow", "classefc_1_1OWindow.html#a95ca8430661cb7bb742b4bba9b5a4952", null ],
    [ "get_data", "classefc_1_1OWindow.html#a3b2e4975e221006d0fa253438e74b2b9", null ],
    [ "get_data_size", "classefc_1_1OWindow.html#a01886b4a25cc33d062c63e1908e47dc7", null ],
    [ "get_scroll_index", "classefc_1_1OWindow.html#a6ca5318015cbded809b6e0304c64466e", null ],
    [ "get_title_x", "classefc_1_1OWindow.html#aa0224c53de48b27b7bc791f3ff1fe9fc", null ],
    [ "get_title_y", "classefc_1_1OWindow.html#a6fa50bf6b31b39e3c9c2a14cedd70aac", null ],
    [ "scroll_down", "classefc_1_1OWindow.html#a360df1d628255154c3cefce86d88499d", null ],
    [ "scroll_up", "classefc_1_1OWindow.html#aac80548173360aa9c8336b60330a14a8", null ],
    [ "set_data", "classefc_1_1OWindow.html#ae8e1bfbd75a83c820e825a73765a5691", null ]
];