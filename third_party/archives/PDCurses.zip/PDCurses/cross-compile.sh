cd ./wincon
make -f Makefile pdcurses.a